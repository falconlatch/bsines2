const forge = require('node-forge');
const fs = require('fs');
const path = require('path');

// Ensure certificate directory exists
const certDir = path.join(__dirname, 'cert');
if (!fs.existsSync(certDir)) {
    fs.mkdirSync(certDir, { recursive: true });
}

// Generate key pair
const keys = forge.pki.rsa.generateKeyPair(2048);
const cert = forge.pki.createCertificate();

// Setup certificate details
cert.publicKey = keys.publicKey;
cert.serialNumber = '01';
cert.validity.notBefore = new Date();
cert.validity.notAfter = new Date();
cert.validity.notAfter.setFullYear(cert.validity.notBefore.getFullYear() + 1);

const attrs = [
    {
        name: 'commonName',
        value: 'localhost'
    },
    {
        name: 'organizationName',
        value: 'Test Certificate'
    }
];

cert.setSubject(attrs);
cert.setIssuer(attrs);
cert.sign(keys.privateKey);

// Convert to PEM format
const privPem = forge.pki.privateKeyToPem(keys.privateKey);
const certPem = forge.pki.certificateToPem(cert);

// Save files
fs.writeFileSync(path.join(certDir, 'key.pem'), privPem);
fs.writeFileSync(path.join(certDir, 'cert.pem'), certPem);

console.log('Certificate files generated successfully!');