const express = require('express');
const https = require('https');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const fs = require('fs');

// Certificate options
const options = {
    key: fs.readFileSync(path.join(__dirname, 'cert', 'key.pem')),
    cert: fs.readFileSync(path.join(__dirname, 'cert', 'cert.pem'))
};

const app = express();
const server = https.createServer(options, app);
const wss = new WebSocket.Server({ server });

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Store active users and waiting users
const users = new Map();
const waitingUsers = new Set();

// Function to find a random chat partner
function findRandomPartner(currentUserId) {
    for (const waitingUserId of waitingUsers) {
        if (waitingUserId !== currentUserId) {
            waitingUsers.delete(waitingUserId);
            return Array.from(users.values()).find(u => u.id === waitingUserId);
        }
    }
    return null;
}

// Broadcast user list to all clients
function broadcastUserList() {
    const userList = Array.from(users.values())
        .filter(user => user.username)
        .map(user => ({
            id: user.id,
            username: user.username,
            status: user.status
        }));

    const message = JSON.stringify({
        type: 'userList',
        users: userList
    });

    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(message);
        }
    });
}

function broadcastUserCount() {
    const count = users.size;
    const message = JSON.stringify({
        type: 'userCount',
        count: count
    });

    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(message);
        }
    });
}

// Generate random user ID
function generateUserId() {
    return Math.random().toString(36).substr(2, 9);
}

// WebSocket connection handler
wss.on('connection', (ws) => {
    // Assign unique ID to new user
    const userId = generateUserId();
    users.set(ws, {
        id: userId,
        status: 'online',
        ws: ws
    });

    // Send user their ID
    ws.send(JSON.stringify({
        type: 'userId',
        userId: userId
    }));

    broadcastUserCount();

    // Handle incoming messages
    ws.on('message', (message) => {
        const data = JSON.parse(message);
        
        switch(data.type) {
            case 'setUsername':
                const user = users.get(ws);
                user.username = data.username;
                user.age = data.age;         
                user.country = data.country;
                broadcastUserList();
                broadcastUserCount();
                break;

            case 'findRandomChat':
                const searchingUser = users.get(ws);
                waitingUsers.add(searchingUser.id);
                
                const partner = findRandomPartner(searchingUser.id);
                if (partner) {
                    // Remove current user from waiting list
                    waitingUsers.delete(searchingUser.id);
                    
                    // Update both users' status
                    searchingUser.status = 'busy';
                    partner.status = 'busy';
                    
                    // Connect the users
                    partner.ws.paired = ws;
                    ws.paired = partner.ws;
                    
                    // Notify both users
                    partner.ws.send(JSON.stringify({
                        type: 'chatRequest',
                        from: searchingUser.id,
                        username: searchingUser.username,
                        isRandom: true
                    }));
                    
                    ws.send(JSON.stringify({
                        type: 'randomPartnerFound',
                        partnerId: partner.id,
                        username: partner.username
                    }));
                    
                    broadcastUserList();
                }
                break;

                case 'randomPartnerFound':
                    // Existing code...
                    ws.send(JSON.stringify({
                        type: 'peerInfo',
                        peerData: {
                            nickname: partner.username,
                            age: partner.age, // You'll need to store this when setting user info
                            country: partner.country // You'll need to store this when setting user info
                        }
                    }));
                    break;

            case 'skipChat':
                if (ws.paired) {
                    const currentUser = users.get(ws);
                    const pairedUser = users.get(ws.paired);
                    
                    // Reset status
                    currentUser.status = 'online';
                    pairedUser.status = 'online';
                    
                    // Notify partner
                    ws.paired.send(JSON.stringify({ 
                        type: 'chatEnded',
                        reason: 'skipped'
                    }));
                    ws.paired.paired = null;
                    ws.paired = null;
                    
                    // Find new partner
                    waitingUsers.add(currentUser.id);
                    const newPartner = findRandomPartner(currentUser.id);
                    if (newPartner) {
                        waitingUsers.delete(currentUser.id);
                        currentUser.status = 'busy';
                        newPartner.status = 'busy';
                        
                        newPartner.ws.paired = ws;
                        ws.paired = newPartner.ws;
                        
                        newPartner.ws.send(JSON.stringify({
                            type: 'chatRequest',
                            from: currentUser.id,
                            username: currentUser.username,
                            isRandom: true
                        }));
                        
                        ws.send(JSON.stringify({
                            type: 'randomPartnerFound',
                            partnerId: newPartner.id,
                            username: newPartner.username
                        }));
                    }
                    
                    broadcastUserList();
                }
                break;

            case 'offer':
            case 'answer':
            case 'ice-candidate':
                if (ws.paired) {
                    ws.paired.send(JSON.stringify(data));
                }
                break;

            case 'chatMessage':
                if (ws.paired) {
                    ws.paired.send(JSON.stringify({
                        type: 'chatMessage',
                        message: data.message,
                        from: users.get(ws).username
                    }));
                }
                break;

            case 'endChat':
                if (ws.paired) {
                    const currentUser = users.get(ws);
                    const pairedUser = users.get(ws.paired);
                    
                    currentUser.status = 'online';
                    pairedUser.status = 'online';
                    
                    ws.paired.send(JSON.stringify({ type: 'chatEnded' }));
                    ws.paired.paired = null;
                    ws.paired = null;
                    
                    broadcastUserList();
                }
                break;
        }
    });

    // Handle client disconnect
    ws.on('close', () => {
        if (ws.paired) {
            const pairedUser = users.get(ws.paired);
            if (pairedUser) {
                pairedUser.status = 'online';
                ws.paired.send(JSON.stringify({ type: 'chatEnded' }));
                ws.paired.paired = null;
            }
        }
        
        const user = users.get(ws);
        if (user) {
            waitingUsers.delete(user.id);
        }
        users.delete(ws);
        broadcastUserList();
        broadcastUserCount();
    });
});

// Create HTTP server to redirect to HTTPS
const httpServer = http.createServer((req, res) => {
    res.writeHead(301, { Location: `https://${req.headers.host}${req.url}` });
    res.end();
});

// Development ports
const HTTP_PORT = 3000;
const HTTPS_PORT = 3001;

// Start servers
httpServer.listen(HTTP_PORT, () => {
    console.log(`HTTP Server running on port ${HTTP_PORT}`);
});

server.listen(HTTPS_PORT, () => {
    console.log(`HTTPS Server running on port ${HTTPS_PORT}`);
});